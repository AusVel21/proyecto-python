# config.py
import os


class Config:
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", "mysql://root:12345678@localhost:3306/app-python"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
